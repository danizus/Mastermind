import Image from "next/image";
import videoPlaceholder from "@images/74865187454.jpg";
import Header from "./partials/Header";
import Footer from "./partials/Footer";
import { CustomButton } from "@/app/components/theme";
import Testimonials from "./components/Home/Testimonials";
import TextContent from "./components/Home/TextContent";
import Hero from "@/app/components/Home/Hero";
import Achievements from "./components/Home/Achievements";
import ProcessDesign from "./components/Home/ProcessDesign";

import AnimatedTitleOnScroll from "./components/Home/AnimatedTitleOnScroll";
import Portfolio from "./components/Home/Portfolio";
import AosComponent from "./components/caseStudies/AosComponent";
import "aos/dist/aos.css";
import LogosSection from "./components/Home/LogosSection";

export default function Home() {
  return (
    <div className="website-wrapper">
      <AosComponent />
      <Header />
      <main>
        {/* HERO SECTION */}
        <Hero />
        {/* HERO SECTION */}

        {/* VIDEO SECTION */}
        <section className="video-section pb-12">
          <div className="container">
            <div className="video-wrap">
              <Image
                src={videoPlaceholder}
                width={1770}
                height={900}
                alt="Video"
                className="w-full"
              />
            </div>
          </div>
        </section>
        {/* VIDEO SECTION */}

        {/* TEXT CONTENT SECTION */}
        <TextContent />
        {/* TEXT CONTENT SECTION */}

        {/* PROCESS DRIVEN SECTION */}
        <ProcessDesign />
        {/* PROCESS DRIVEN SECTION */}
        {/* Logos section */}

        <LogosSection />

        {/* Logos section */}

        {/* PORTFOLIO SECTION */}
        <Portfolio />
        {/* PORTFOLIO SECTION */}

        <section className="svg-line-animation-wrapper">
          {/* ACHIEVEMENTS SECTION */}
          <Achievements />
          {/* ACHIEVEMENTS SECTION */}

          {/* TESTIMONIALS SECTION */}
          <section className="testimonials-section relative z-10 bg-[#3239FF] py-12 text-white lg:py-20 xl:py-24 2xl:py-32">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="1749"
              height="968"
              fill="none"
              viewBox="0 0 1749 968"
              className="absolute right-0 top-0 -z-10 h-auto w-[90%] max-w-[1450px]"
            >
              <path
                stroke="#5C62FF"
                d="M1748.5 965v.5H801C358.896 965.5.5 607.104.5 165V.5h1748V965z"
              ></path>
              <path
                stroke="#5C62FF"
                d="M1748.5 658v.5H809c-276.419 0-500.5-224.081-500.5-500.5V.5h1440V658z"
              ></path>
              <circle
                cx="2.5"
                cy="2.5"
                r="2.5"
                fill="#5C62FF"
                transform="matrix(1 0 0 -1 918 661)"
              ></circle>
              <circle
                cx="2.5"
                cy="2.5"
                r="2.5"
                fill="#5C62FF"
                transform="matrix(1 0 0 -1 1668 968)"
              ></circle>
              <circle
                cx="2.5"
                cy="2.5"
                r="2.5"
                fill="#5C62FF"
                transform="matrix(1 0 0 -1 306 172)"
              ></circle>
              <circle
                cx="2.5"
                cy="2.5"
                r="2.5"
                fill="#5C62FF"
                transform="matrix(1 0 0 -1 243 744)"
              ></circle>
            </svg>
            <div className="container">
              <div className="mb-8 grid items-start gap-4 md:mb-12 md:grid-cols-4 lg:mb-16 xl:mb-20 2xl:mb-28">
                <div className="col-span-1">
                  <p className="text-sm font-light !leading-9 md:text-base lg:text-xl">
                    Testimonials
                  </p>
                </div>
                <div className="col-span-2 ">
                  <AnimatedTitleOnScroll
                    leftText="And also"
                    rightText="they love us"
                  />
                </div>
                {/* <div className="col-span-1 flex md:justify-end">
                  <CustomButton bgClassNames="bg-[#4D53FF]">
                    View all
                  </CustomButton>
                </div> */}
              </div>
              <div className="flex justify-end">
                <div className="lg:w-5/6 xl:px-10">
                  <Testimonials />
                </div>
              </div>
            </div>
          </section>
          {/* TESTIMONIALS SECTION */}
        </section>

        {/* CTA SECTION */}
        <section className="relative py-20 md:py-24 lg:py-28 xl:py-32 2xl:py-36">
          <div
            className="qodef-m-background-grid-lines qodef-m-background-grid-lines--4"
            style={
              {
                "--qode-grid-lines-color": "rgb(239,239,239)",
              } as React.CSSProperties
            }
          >
            <div
              className="qodef-m-background-grid-line"
              style={{ left: "20%" }}
            ></div>
            <div
              className="qodef-m-background-grid-line"
              style={{ left: "35%" }}
            ></div>
            <div
              className="qodef-m-background-grid-line"
              style={{ left: "65%" }}
            ></div>
            <div
              className="qodef-m-background-grid-line"
              style={{ left: "80%" }}
            ></div>
          </div>
          <div data-aos={"fade-right"} className="container">
            <div className="text-center">
              <h2 className="mb-10 text-2xl font-medium md:text-3xl lg:mb-12 lg:text-5xl xl:mb-32 xl:text-6xl 2xl:text-8xl">
                Ready to kick off our collaboration?
              </h2>
              <p className="mx-auto mb-10 max-w-5xl text-xs font-light text-[#878C8E] md:mb-12 md:text-base lg:mb-32 lg:text-lg">
                Ready to bring your vision to life? Whether you need a brand
                refresh, a stunning website, or an innovative product, we&apos;re
                here to help. Our expert team delivers exceptional results
                tailored to your business needs. Let&apos;s collaborate to turn your
                ideas into impactful solutions. Ready to start? Let&apos;s talk about
                how we can work together.
              </p>
              <div className="flex flex-col items-center justify-center gap-5 md:flex-row md:gap-20">
                <CustomButton href="https://calendly.com/volkohdesign">
                  Book a Demo Call
                </CustomButton>
                <CustomButton href="/contact">Contact Us</CustomButton>
              </div>
            </div>
          </div>
        </section>
        {/* CTA SECTION */}
      </main>
      <Footer />
    </div>
  );
}
