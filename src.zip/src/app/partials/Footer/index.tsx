import FooterLogoAnimation from "./FooterLogoAnimation";

export default function Footer() {
  return (
    <footer className="site-footer relative z-10 overflow-hidden bg-[#17191B] pt-20 text-white md:pt-24 lg:pt-28 xl:pt-32 2xl:pt-36">
      <FooterLogoAnimation />
      <div className="container">
        <div className="grid grid-cols-12">
          <div className="col-span-7">
            <h2 className="mb-8 text-base sm:text-lg md:mb-12 md:text-xl lg:mb-16 lg:text-2xl xl:text-3xl 2xl:text-4xl">
              Don&apos;t let your idea stay a dream.
            </h2>
            <div className="mb-8 flex flex-wrap items-center gap-6 border-b border-solid border-[#323639] pb-8 md:mb-12 md:pb-12 lg:mb-16 lg:pb-16">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="60"
                height="60"
                fill="none"
                viewBox="0 0 64 64"
              >
                <path
                  fill="#3239FF"
                  d="M62.818 32.049L3.606.31C2.01-.544.03.461 0 2.124l.157 59.752c0 1.614 1.916 2.641 3.458 1.853l59.109-27.986c1.68-.778 1.69-2.839.094-3.694zm-18.754 2.604L11.143 50.264c-.522.237-1.16-.105-1.17-.627L9.947 38.58c0-.323-.203-.56-.5-.655L2.765 35.7c-.702-.247-.713-1.092 0-1.291l6.648-2.249c.287-.104.531-.36.5-.636l-.058-15.206c-.011-.522.659-.874 1.19-.588l33.038 17.707c.564.238.533.931-.02 1.216z"
                ></path>
              </svg>

              <a
                href="/contact"
                className="border-b border-solid border-white py-4 text-lg"
              >
                Contact Us
              </a>

              <div className="hidden text-[#878C8E] md:block">or</div>

              <a
         
                href="https://calendly.com/volkohdesign"
                className="border-b border-solid border-white py-4 text-lg"
              >
                Schedule a call
              </a>
            </div>

            <div className="mb-8 flex flex-wrap items-center gap-6 border-b border-solid border-[#323639] pb-8 md:mb-12 md:pb-12 lg:mb-16 lg:pb-16">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="60"
                height="60"
                fill="none"
                viewBox="0 0 64 64"
              >
                <path
                  fill="#3239FF"
                  d="M62.818 32.049L3.606.31C2.01-.544.03.461 0 2.124l.157 59.752c0 1.614 1.916 2.641 3.458 1.853l59.109-27.986c1.68-.778 1.69-2.839.094-3.694zm-18.754 2.604L11.143 50.264c-.522.237-1.16-.105-1.17-.627L9.947 38.58c0-.323-.203-.56-.5-.655L2.765 35.7c-.702-.247-.713-1.092 0-1.291l6.648-2.249c.287-.104.531-.36.5-.636l-.058-15.206c-.011-.522.659-.874 1.19-.588l33.038 17.707c.564.238.533.931-.02 1.216z"
                ></path>
              </svg>

              <div className="md:mr-6 lg:mr-8 xl:mr-10 2xl:mr-12">
                <div className="mb-4 hidden text-[#878C8E] md:block">
                  Business
                </div>
                <a
                  href="mailto:hello@volkoh.com"
                  className="py-2 text-lg md:text-xl lg:text-2xl xl:text-3xl"
                >
                  hello@volkoh.com
                </a>
              </div>

              <div className="md:mr-6 lg:mr-8 xl:mr-10 2xl:mr-12">
                <div className="mb-4 hidden text-[#878C8E] md:block">
                  Careers
                </div>
                <a
                  href="mailto:hiring@volkoh.com"
                  className="py-2 text-lg md:text-xl lg:text-2xl xl:text-3xl"
                >
                  hiring@volkoh.com
                </a>
              </div>
            </div>

            <div className="mb-8 flex flex-wrap items-center gap-6 border-b border-solid border-[#323639] pb-8 md:mb-12 md:pb-12 lg:mb-16 lg:pb-16">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="60"
                height="60"
                fill="none"
                viewBox="0 0 64 64"
              >
                <path
                  fill="#3239FF"
                  d="M62.818 32.049L3.606.31C2.01-.544.03.461 0 2.124l.157 59.752c0 1.614 1.916 2.641 3.458 1.853l59.109-27.986c1.68-.778 1.69-2.839.094-3.694zm-18.754 2.604L11.143 50.264c-.522.237-1.16-.105-1.17-.627L9.947 38.58c0-.323-.203-.56-.5-.655L2.765 35.7c-.702-.247-.713-1.092 0-1.291l6.648-2.249c.287-.104.531-.36.5-.636l-.058-15.206c-.011-.522.659-.874 1.19-.588l33.038 17.707c.564.238.533.931-.02 1.216z"
                ></path>
              </svg>

              <div className="md:mr-6 lg:mr-8 xl:mr-10 2xl:mr-12">
                <div className="mb-4 hidden text-[#878C8E] md:block">
                  Social
                </div>
                <div className="flex gap-6 md:gap-8">
                  <a href="https://www.instagram.com/volkoh.design" className="py-2 text-base lg:text-xl">
                    Instagram
                  </a>
                  <a href="https://dribbble.com/Volkohdesign" className="py-2 text-base lg:text-xl">
                  Dribbble
                  </a>
                  <a href="https://www.linkedin.com/company/volkoh/" className="py-2 text-base lg:text-xl">
                  LinkedIn
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-between pb-8 md:pb-12 lg:pb-16">
          <ul className="flex gap-x-8 md:gap-x-10 lg:gap-x-12 xl:gap-x-16">
            <li>
              <a
                href="/work"
                className="transition-all duration-200 hover:text-primary"
              >
                Our Work
              </a>
            </li>
            <li>
              <a
                href="/about"
                className="transition-all duration-200 hover:text-primary"
              >
                About Us
              </a>
            </li>
            <li>
              <a
                href="/contact"
                className="transition-all duration-200 hover:text-primary"
              >
                Contact Us
              </a>
            </li>
          </ul>
          <div className="mb-4 hidden text-[#878C8E] md:block">
            © Copyright 2024 Volkoh
          </div>
        </div>
      </div>
    </footer>
  );
}
