

import React, { useState } from "react";
import Header from "../partials/Header";
import InsidePagesHero from "../components/work/InsidePagesHero";
import Footer from "../partials/Footer";
import portfolio1 from "@images/Rectangle 40615portfolio.jpg";
import portfolio2 from "@images/Rectangle 40615portfolio-1.jpg";
import portfolio3 from "@images/Rectangle 40615portfolio-3.jpg";
import portfolio4 from "@images/Rectangle 40615portfolio-2.jpg";
import portfolio5 from "@images/portfolio5.png";
import portfolio7 from "@images/portfolio7.png";
import Image from "next/image";
import Link from "next/link";
import AosComponent from "../components/caseStudies/AosComponent";
import "aos/dist/aos.css";

const portfolio = [
  {
    title: "Homeloop",
    description:
      "A dynamic platform for property managers to streamline their ope...",
    tags: ["Real Estate", "Property Management", "User Experience"],
    image: portfolio1,
    link: "/homeloop",
    Animation: "fade-up",
  },
  {
    title: "Pet shack",
    description:
      "An engaging app that connects pet owners with local pet services...",
    tags: ["Pet Care", "Mobile App", "User Engagement"],
    image: portfolio2,
    link: "/petshack-case-study",
    Animation: "fade-down",
  },
];
const portfolioAi = [
  {
    title: "The AI School",
    description:
      "An educational platform designed to make learning artificial intelligence accessible and engaging for all students.",
    tags: ["Education", "Artificial Intelligence", "WebDevelopment"],
    image: portfolio5,
    Animation: "fade-right",
  },
];
const portfolioNew = [
  {
    title: "Cerro System",
    description:
      "A comprehensive system designed to simplify and optimize logist...",
    tags: ["Logistics", "Supply Chain", "Efficiency"],
    image: portfolio3,
    link: "/",
    Animation: "fade-down",
  },
  {
    title: "Flexi Clean",
    description:
      "A revolutionary cleaning services app that simplifies booking and...",
    tags: ["Cleaning Services", "App Development", "Convenience"],
    image: portfolio4,
    link: "/flexi-clean",
    Animation: "fade-up",
  },
];
const portfolioVpn = [
  {
    title: "Keepngive",
    description:
      "A sleek and effective single product sales landing page designed to maximize conversions and customer engagement.",
    tags: ["E-Commerce", "Landing Page", "Conversion Optimization"],
    image: portfolio7,
    Animation: "fade-right",
  },
];

export default function page() {

  return (
    <div className="webiste-wrapper">
      <AosComponent />
      <Header />
      <InsidePagesHero label="We bring your boldest ideas to life" />
      <section className="portfolio-section py-12 lg:py-20 xl:py-24">
        <div className="container">
          <div className="grid grid-cols-1 gap-12  md:grid-cols-2 lg:gap-16 lg:gap-x-20">
            {portfolio.map((item, index) => (
              <Link
                href={item.link}
                className="portfolio-item  md:last-of-type:mt-32"
                key={index}
                data-aos={item.Animation}
              >
                <div className="img-wrap relative mb-4">
                  <Image
                    src={item.image}
                    width={812}
                    height={880}
                    alt="Portfolio Image"
                    className="rounded-lg"
                  />
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 120 120"
                    className="portfolio-inner absolute bottom-5 right-5 h-[80px] w-[80px] opacity-0 xl:bottom-10 xl:right-10 xl:h-[120px] xl:w-[120px]"
                  >
                    <circle cx="60" cy="60" r="60" fill="#3239FF"></circle>
                    <path
                      stroke="#fff"
                      strokeWidth="4"
                      d="M60 40.8v38.4M79.2 60H40.8"
                    ></path>
                  </svg>
                </div>
                <div className="portfolio-content md:p-6">
                  <h4 className="mb-3 text-lg md:mb-6 md:text-xl lg:text-2xl xl:text-3xl">
                    {item.title}
                  </h4>
                  <p className="mb-4 text-xs font-light md:text-base lg:text-lg">
                    {item.description}
                  </p>
                  <div className="portfolio-tags hidden items-center gap-2 font-light md:flex md:gap-4 lg:gap-6">
                    {item.tags.map((tag, index) => (
                      <span key={index}>
                        <span className="text-xs md:text-sm">Web Design</span>
                        <span className="h-[5px] w-[5px] rounded-full bg-[#323639] last:hidden"></span>
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section className="portfolio-section py-12 lg:gap-16 xl:py-24">
        <div className="container">
          <div className=" grid grid-cols-1 gap-4 sm:gap-6 md:gap-12 lg:gap-16 lg:gap-x-20">
            {portfolioAi.map((item, index) => (
              <Link
                href="/"
                className="  portfolio-item duration-300 ease-in-out md:odd:mt-24 "
                key={index}
                data-aos={item.Animation}
              >
                <div className="img-wrap relative mb-4">
                  <Image
                    src={item.image}
                    width={1527}
                    height={880}
                    alt="Portfolio Image"
                    className="rounded-lg"
                  />

                  <div className="portfolio-inner  absolute  bottom-2 right-4 rounded-full bg-[#3239FF] px-4 py-2 text-center text-white opacity-0 xl:bottom-10 xl:right-32 xl:px-8  xl:py-4">
                    Coming Soon
                  </div>
                </div>
                <div className="portfolio-content md:p-6">
                  <h4 className="mb-3 text-lg md:mb-6 md:text-xl lg:text-2xl xl:text-3xl">
                    {item.title}
                  </h4>
                  <p className="mb-4 text-xs font-light md:text-base lg:text-lg">
                    {item.description}
                  </p>
                  <div className="portfolio-tags hidden items-center gap-2 font-light md:flex md:gap-4 lg:gap-6">
                    {item.tags.map((tag, index) => (
                      <span key={index}>
                        <span className="text-xs md:text-sm">Web Design</span>
                        <span className="h-[5px] w-[5px] rounded-full bg-[#323639] last:hidden"></span>
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section className="portfolio-section py-12 lg:py-16 xl:py-24">
        <div className="container">
          <div className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 md:gap-12 lg:gap-16 lg:gap-x-20">
            {portfolioNew.map((item, index) => (
              <Link
                href={item.link}
                className="portfolio-item duration-300  ease-in-out  md:odd:mt-32"
                key={index}
                data-aos={item.Animation}
              >
                <div className="img-wrap relative mb-4">
                  <Image
                    src={item.image}
                    width={812}
                    height={880}
                    alt="Portfolio Image"
                    className="rounded-lg"
                  />
                  {index === 1 ? (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 120 120"
                      className="portfolio-inner absolute bottom-5 right-5 h-[80px] w-[80px] opacity-0 xl:bottom-10 xl:right-10 xl:h-[120px] xl:w-[120px]"
                    >
                      <circle cx="60" cy="60" r="60" fill="#3239FF"></circle>
                      <path
                        stroke="#fff"
                        strokeWidth="4"
                        d="M60 40.8v38.4M79.2 60H40.8"
                      ></path>
                    </svg>
                  ) : (
                    <div className="portfolio-inner  absolute  bottom-2 right-4 rounded-full bg-[#3239FF] px-4 py-2 text-center text-white opacity-0 xl:bottom-10 xl:right-10 xl:px-8  xl:py-4">
                      Coming Soon
                    </div>
                  )}
                </div>
                <div className="portfolio-content md:p-6">
                  <h4 className="mb-3 text-lg md:mb-6 md:text-xl lg:text-2xl xl:text-3xl">
                    {item.title}
                  </h4>
                  <p className="mb-4 text-xs font-light md:text-base lg:text-lg">
                    {item.description}
                  </p>
                  <div className="portfolio-tags hidden items-center gap-2 font-light md:flex md:gap-4 lg:gap-6">
                    {item.tags.map((tag, index) => (
                      <span key={index}>
                        <span className="text-xs md:text-sm">Web Design</span>
                        <span className="h-[5px] w-[5px] rounded-full bg-[#323639] last:hidden"></span>
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section className="portfolio-section py-12 lg:py-20 xl:py-24">
        <div className="container">
          <div className=" grid grid-cols-1 gap-4 sm:gap-6 md:gap-12 lg:gap-16 lg:gap-x-20">
            {portfolioVpn.map((item, index) => (
              <Link
                href="/"
                className=" portfolio-item  md:odd:mt-24"
                key={index}
                data-aos={item.Animation}
              >
                <div className="img-wrap relative  mb-4 ">
                  <Image
                    src={item.image}
                    width={1527}
                    height={880}
                    alt="Portfolio Image"
                    className="rounded-lg"
                  />
                  <div className="portfolio-inner  absolute  bottom-2 right-4 rounded-full bg-[#3239FF] px-4 py-2 text-center text-white opacity-0 xl:bottom-10 xl:right-32 xl:px-8  xl:py-4">
                    Coming Soon
                  </div>
                </div>
                <div className="portfolio-content md:p-6">
                  <h4 className="mb-3 text-lg md:mb-6 md:text-xl lg:text-2xl xl:text-3xl">
                    {item.title}
                  </h4>
                  <p className="mb-4 text-xs font-light md:text-base lg:text-lg">
                    {item.description}
                  </p>
                  <div className="portfolio-tags hidden items-center gap-2 font-light md:flex md:gap-4 lg:gap-6">
                    {item.tags.map((tag, index) => (
                      <span key={index}>
                        <span className="text-xs md:text-sm">Web Design</span>
                        <span className="h-[5px] w-[5px] rounded-full bg-[#323639] last:hidden"></span>
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
}
