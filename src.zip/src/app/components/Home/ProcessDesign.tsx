import { Button } from "@/components/ui/button";
import { CustomButton } from "../theme";
import AnimatedTitleOnScroll from "./AnimatedTitleOnScroll";
import Link from "next/link";

export default function ProcessDesign() {
  return (
    <section className="process-section relative pt-12 text-white lg:pt-20 xl:pt-24 2xl:pt-32 ">
      <div className="container">
        <div className="my-14 grid grid-cols-1 items-start gap-4 md:grid-cols-4">
          <div className="col-span-1">
            <p className="text-sm font-light !leading-9 md:text-base lg:text-xl">
              Our Services
            </p>
          </div>
          <div className="col-span-2 pt-12">
            <AnimatedTitleOnScroll
              leftText="Process"
              rightText="driven design"
            />
          </div>
          <div className="col-span-1 flex md:justify-end">
            <CustomButton href="/work" bgClassNames="bg-[#4D53FF]">
              What we do
            </CustomButton>
          </div>
        </div>
        <div className="grid-items-start grid pt-12 md:grid-cols-2 lg:grid-cols-4 lg:pt-20 xl:pt-24 2xl:pt-32">
          <div className="group border-solid border-white px-6 py-8 transition-all duration-300 ease-in-out hover:bg-white hover:text-black md:border-r">
            <h4 className="mb-6 text-xl lg:text-2xl xl:text-3xl">
              User Experience Design
            </h4>
            <Link
              href="#"
              className="mb-6  block max-w-fit opacity-0 group-hover:opacity-100"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                fill="none"
                viewBox="0 0 50 50"
              >
                <circle cx="25" cy="25" r="25" fill="#17191B"></circle>
                <path stroke="#fff" d="M24.928 21L24.928 29"></path>
                <path stroke="#fff" d="M29 24.929L21 24.929"></path>
              </svg>
            </Link>
            <p className="font-light opacity-0 group-hover:text-[#878C8E] group-hover:opacity-100">
              We design intuitive and engaging interfaces that prioritize user
              needs, ensuring a seamless and satisfying user journey.
            </p>
          </div>
          <div className="group border-solid border-white px-6 py-8 transition-all duration-300 ease-in-out hover:bg-white hover:text-black md:border-r">
            <h4 className="mb-6 text-xl lg:text-2xl xl:text-3xl">
              Custom Website Design
            </h4>
            <Link
              href="#"
              className="mb-6 block max-w-fit opacity-0 group-hover:opacity-100"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                fill="none"
                viewBox="0 0 50 50"
              >
                <circle cx="25" cy="25" r="25" fill="#17191B"></circle>
                <path stroke="#fff" d="M24.928 21L24.928 29"></path>
                <path stroke="#fff" d="M29 24.929L21 24.929"></path>
              </svg>
            </Link>
            <p className="font-light opacity-0 group-hover:text-[#878C8E] group-hover:opacity-100">
              We craft custom websites that reflect your brand and meet your
              business needs, delivering visually stunning and high-performance
              sites.
            </p>
          </div>
          <div className="group border-solid border-white px-6 py-8 transition-all duration-300 ease-in-out hover:bg-white hover:text-black md:border-r">
            <h4 className="mb-8 text-xl lg:text-2xl xl:text-3xl">
              Product Designing
            </h4>
            <Link
              href="#"
              className="mb-6 block max-w-fit opacity-0 group-hover:opacity-100"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                fill="none"
                viewBox="0 0 50 50"
              >
                <circle cx="25" cy="25" r="25" fill="#17191B"></circle>
                <path stroke="#fff" d="M24.928 21L24.928 29"></path>
                <path stroke="#fff" d="M29 24.929L21 24.929"></path>
              </svg>
            </Link>
            <p className="font-light opacity-0 group-hover:text-[#878C8E] group-hover:opacity-100">
              We turn innovative ideas into functional and user-friendly
              products, ensuring high standards of quality and usability.
            </p>
          </div>
          <div className="group mb-10 border-white px-6 py-8 transition-all duration-300 ease-in-out hover:bg-white hover:text-black sm:border-solid md:mb-0 md:border-r lg:border-none">
            <h4 className="mb-8 text-xl lg:text-2xl xl:text-3xl">
              Web & App Development
            </h4>
            <Link
              href="#"
              className="mb-6 block max-w-fit opacity-0 group-hover:opacity-100"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                fill="none"
                viewBox="0 0 50 50"
              >
                <circle cx="25" cy="25" r="25" fill="#17191B"></circle>
                <path stroke="#fff" d="M24.928 21L24.928 29"></path>
                <path stroke="#fff" d="M29 24.929L21 24.929"></path>
              </svg>
            </Link>
            <p className="font-light opacity-0 group-hover:text-[#878C8E] group-hover:opacity-100">
              We build robust and scalable web and mobile applications,
              providing exceptional user experiences with the latest
              technologies.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
