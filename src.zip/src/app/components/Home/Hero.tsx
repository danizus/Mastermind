"use client";
import { CustomButton } from "@/app/components/theme";
import HeroLineAnimation from "./HeroLineAnimation";
import ClutchWidget from "./ClutchWidget";
import Link from "next/link";

export default function Hero() {
  return (
    <section className="relative z-10 overflow-hidden hero-section">
      <HeroLineAnimation />
      <div className="container">
        <div
          className="qodef-m-background-grid-lines qodef-m-background-grid-lines--4"
          style={
            {
              "--qode-grid-lines-color": "rgb(239,239,239)",
            } as React.CSSProperties
          }
        >
          <div
            className="qodef-m-background-grid-line"
            style={{ left: "20%" }}
          ></div>
          <div
            className="qodef-m-background-grid-line"
            style={{ left: "35%" }}
          ></div>
          <div
            className="qodef-m-background-grid-line"
            style={{ left: "65%" }}
          ></div>
          <div
            className="qodef-m-background-grid-line"
            style={{ left: "80%" }}
          ></div>
        </div>
        <div className="mx-auto py-32 sm:py-36 md:py-40 lg:py-48 xl:py-60 2xl:py-72 max-w-screen-xl">
          <h1 className="font-bold text-3xl text-center md:text-4xl lg:text-5xl xl:text-9xl !leading-tight">
            User-centered design! delivering results!
          </h1>
        </div>
        <div className="flex md:flex-row flex-col justify-between items-center gap-5 pb-6">
          <ClutchWidget />

          <CustomButton href="https://calendly.com/volkohdesign">
            Book a Demo Call
          </CustomButton>
        </div>
      </div>
    </section>
  );
}
