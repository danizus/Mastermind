"use client";
import petshack from "@images/petshacklogo.png";
import hrmforce from "@images/hrmforce.png";
import keepgive from "@images/keepgive.png";
import homeloop from "@images/homeloop.png";
import reisigo from "@images/reisigo.png";
import liv from "@images/liv.png";
import zestal from "@images/zestal.png";
import wavesense from "@images/wavesense.png";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";

import { Autoplay } from "swiper/modules";
import "swiper/css/navigation";
import "swiper/css/pagination";

import "swiper/css/autoplay";
import Image from "next/image";

export default function LogosSection() {
  return (
    <Swiper
      modules={[Autoplay]}
      slidesPerView={1}
      autoplay={{ delay: 0 }}
      speed={2000}
      loop={true}
      className="bg-[#F2F2F2]"
    >
      <SwiperSlide className=" whitespace-nowrap text-center text-5xl font-medium text-white md:text-9xl lg:text-[200px]">
        <div className="flex   items-center justify-between gap-10  p-6 md:p-14 ">
          <Image src={hrmforce} width={178} height={40} alt="hrmforce" />
          <Image src={keepgive} width={214} height={40} alt="keepgive" />
          <Image src={homeloop} width={141} height={40} alt="homeloop" />
          <Image src={reisigo} width={150} height={40} alt="reisigo" />
          <Image src={zestal} width={89} height={40} alt="reisigo" />
          <Image src={liv} width={70} height={40} alt="liv" />
          <Image src={wavesense} width={266} height={40} alt="wavesense" />
        </div>
      </SwiperSlide>
      <SwiperSlide className=" whitespace-nowrap text-center text-5xl font-medium text-white md:text-9xl  lg:text-[200px]">
        <div className="hidden lg:flex items-center justify-between gap-10  p-14 ">
          <Image src={hrmforce} width={178} height={40} alt="hrmforce" />
          <Image src={keepgive} width={214} height={40} alt="keepgive" />
          <Image src={homeloop} width={141} height={40} alt="homeloop" />
          <Image src={reisigo} width={150} height={40} alt="reisigo" />
          <Image src={zestal} width={89} height={40} alt="reisigo" />
          <Image src={liv} width={70} height={40} alt="liv" />
          <Image src={wavesense} width={266} height={40} alt="wavesense" />
        </div>
      </SwiperSlide>
      <SwiperSlide className=" whitespace-nowrap text-center text-5xl font-medium text-white md:text-9xl lg:text-[200px]">
        <div className="hidden lg:flex items-center justify-between gap-10  p-14 ">
          <Image src={hrmforce} width={178} height={40} alt="hrmforce" />
          <Image src={keepgive} width={214} height={40} alt="keepgive" />
          <Image src={homeloop} width={141} height={40} alt="homeloop" />
          <Image src={reisigo} width={150} height={40} alt="reisigo" />
          <Image src={zestal} width={89} height={40} alt="reisigo" />
          <Image src={liv} width={70} height={40} alt="liv" />
          <Image src={wavesense} width={266} height={40} alt="wavesense" />
        </div>
      </SwiperSlide>
    </Swiper>
  );
}
