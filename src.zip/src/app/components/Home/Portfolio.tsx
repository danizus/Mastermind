"use client";
import React, { useState } from "react";
import portfolio1 from "@images/Rectangle 40615portfolio.jpg";
import portfolio2 from "@images/Rectangle 40615portfolio-1.jpg";
import portfolio3 from "@images/Rectangle 40615portfolio-3.jpg";
import portfolio4 from "@images/Rectangle 40615portfolio-2.jpg";
import Link from "next/link";
import Image from "next/image";
import { CustomButton } from "../theme";

const portfolio = [
  {
    title: "Homeloop",
    description:
      "A dynamic platform for property managers to streamline their ope...",
    tags: ["Real Estate", "Property Management", "User Experience"],
    image: portfolio1,
    link: "/homeloop",
  },
  {
    title: "Pet shack",
    description:
      "An engaging app that connects pet owners with local pet services...",
    tags: ["Pet Care", "Mobile App", "User Engagement"],
    image: portfolio2,
    link: "/petshack-case-study",
  },
  {
    title: "Cerro System",
    description: "A comprehensive system designed to simplify and optimize logist...",
    tags: ["Logistics", "Supply Chain", "Efficiency"],
    image: portfolio3,
    link: "javascript:void(0)",
    comingSoon: true
  },
  {
    title: "Flexi Clean",
    description:
      "A revolutionary cleaning services app that simplifies booking and...",
    tags: ["Cleaning Services", "App Development", "Convenience"],
    image: portfolio4,
    link: "/flexi-clean",
  },
];

export default function Portfolio() {
  const [hoveredIndex, setHoveredIndex] = useState<any>(null);
  return (
    <section className="py-12 lg:py-20 xl:py-24 portfolio-section">
      <div className="container">
        <div className="items-start gap-4 grid md:grid-cols-4 mb-10 lg:mb-20">
          <div className="col-span-1">
            <p className="font-light text-sm md:text-base lg:text-xl">
              Portfolio
            </p>
          </div>
          <div className="col-span-2">
            <h2 className="max-w-full lg:max-w-[80%] xl:max-w-[60%] font-bold text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl">
              We bring your boldest ideas to life
            </h2>
          </div>
          <div className="flex md:justify-end col-span-1">
            <CustomButton href="/about">View all projects</CustomButton>
          </div>
        </div>
        <div className="gap-4 sm:gap-6 md:gap-12 lg:gap-16 lg:gap-x-20 grid md:grid-cols-2 grid-col-1">
          {portfolio.map((item, index) => (
            <Link
              href={item.link}
              key={index}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
              className="duration-300 ease-in-out group portfolio-item"
            >
              <div className="relative mb-4 overflow-hidden img-wrap">
                <Image
                  src={item.image}
                  width={812}
                  height={880}
                  alt="Portfolio Image"
                  className="rounded-lg"
                />
                {!item.comingSoon && (
                  <div className="right-4 md:right-8 xl:right-12 bottom-4 md:bottom-8 xl:bottom-12 z-10 absolute flex justify-center items-center bg-primary rounded-full size-16 md:size-20 xl:size-28 opacity-0 group-hover:opacity-100 transition-all translate-y-full group-hover:translate-y-0 duration-300">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    fill="none"
                    viewBox="0 0 40 40"
                    className="size-6 md:size-8 lg:size-10"
                  >
                    <path stroke="#fff" strokeWidth="4" d="M20 .8v38.4M39.2 20H.8"></path>
                  </svg>
                </div>
                )}
                {item.comingSoon && (
                  <div className="right-4 md:right-8 xl:right-12 bottom-4 md:bottom-8 xl:bottom-12 z-10 absolute flex justify-center items-center bg-primary opacity-0 group-hover:opacity-100 px-6 py-3 rounded-full text-white transition-all translate-y-full group-hover:translate-y-0 duration-300">
                  Coming Soon
                </div>
                )}
              </div>
              <div className="md:p-6 portfolio-content">
                <h4 className="mb-3 md:mb-6 text-lg md:text-xl lg:text-2xl xl:text-3xl">
                  {item.title}
                </h4>
                <p className="mb-4 font-light text-xs md:text-base lg:text-lg">
                  {item.description}
                </p>
                <div className="md:flex flex-wrap items-center gap-2 md:gap-3 xl:gap-6 hidden font-light portfolio-tags">
                  {item.tags.map((tag, index) => (
                    <span key={index} className="group">
                      <span className="text-xs md:text-sm">{tag}</span>
                      <span className="md:inline-block hidden group-last:hidden bg-[#323639] ml-4 rounded-full w-[5px] h-[5px] align-middle"></span>
                    </span>
                  ))}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
