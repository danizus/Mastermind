"use client";
import CountUp from "react-countup";
import { useInView } from "react-intersection-observer";

export default function Achievements() {
  const { ref, inView } = useInView({
    // triggerOnce: true,
    threshold: 0.5,
  });
  return (
    <section className="relative z-10 bg-[#17191B] py-20 md:py-24 lg:py-32 xl:py-36 2xl:py-40 text-white">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="1749"
        height="968"
        fill="none"
        viewBox="0 0 1749 968"
        className="right-0 bottom-0 -z-10 absolute w-[90%] max-w-[1450px] h-auto"
      >
        <path
          stroke="#323639"
          d="M1748.5 3v-.5H801C358.896 2.5.5 360.896.5 803v164.5h1748V3z"
        ></path>
        <path
          stroke="#323639"
          d="M1748.5 310v-.5H809c-276.419 0-500.5 224.081-500.5 500.5v157.5h1440V310z"
        ></path>
        <circle cx="920.5" cy="309.5" r="2.5" fill="#323639"></circle>
        <circle cx="1670.5" cy="2.5" r="2.5" fill="#323639"></circle>
        <circle cx="308.5" cy="798.5" r="2.5" fill="#323639"></circle>
        <circle cx="245.5" cy="226.5" r="2.5" fill="#323639"></circle>
      </svg>
      <div className="container" ref={ref}>
        <div className="items-start gap-4 grid md:grid-cols-4">
          <div className="col-span-1">
            <p className="font-light text-sm md:text-base lg:text-xl">
              Awards Win
            </p>
          </div>
          <div className="col-span-3">
            <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl !leading-tight">
              We design creative brands, websites, and product packages that
              deliver results.
            </h2>
          </div>
        </div>
        <div className="gap-24 md:gap-20 lg:gap-24 xl:gap-28 2xl:gap-48 grid md:grid-cols-3 pt-20 md:pt-24 lg:pt-32 xl:pt-36 2xl:pt-40">
          <div className="counter-wrap">
            <h4 className="font-medium text-2xl md:text-3xl lg:text-5xl xl:text-6xl 2xl:text-8xl">
              <CountUp end={inView ? 500 : 0} suffix="+" />
            </h4>
            <div className="border-white my-8 md:my-12 border-b border-solid"></div>
            <p className="text-xs md:text-base lg:text-lg">
              We have successfully completed over 500 projects, delivering
              exceptional design solutions that drive business success.
            </p>
          </div>
          <div className="counter-wrap">
            <h4 className="font-medium text-2xl md:text-3xl lg:text-5xl xl:text-6xl 2xl:text-8xl">
              <CountUp end={inView ? 9 : 0} />
            </h4>
            <div className="border-white my-8 md:my-12 border-b border-solid"></div>
            <p className="text-xs md:text-base lg:text-lg">
              With 9 years in the industry, our expertise spans across various
              domains, ensuring high-quality and innovative designs.
            </p>
          </div>
          <div className="counter-wrap">
            <h4 className="font-medium text-2xl md:text-3xl lg:text-5xl xl:text-6xl 2xl:text-8xl">
              <CountUp end={inView ? 200 : 0} suffix="+" />
            </h4>
            <div className="border-white my-8 md:my-12 border-b border-solid"></div>
            <p className="text-xs md:text-base lg:text-lg">
              We have worked with over 200 clients, building strong partnerships
              and creating designs that meet their unique needs and goals.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
