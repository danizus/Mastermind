"use client";
import Image from "next/image";
import { Navigation, Pagination, Scrollbar, A11y } from "swiper/modules";

import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

export default function Testimonials() {
  return (
    <Swiper
      modules={[Pagination, A11y]}
      slidesPerView={1}
      pagination={{ clickable: true }}
      direction={"vertical"}
      autoHeight={true}
      height={360}
      style={
        {
          "--swiper-pagination-left": "40px",
          "--swiper-pagination-right": "auto",
          paddingLeft: "max(40px, min(5vw, 100px))",
        } as React.CSSProperties
      }
    >
      <SwiperSlide>
        <div className="testimonial-item px-12">
          <p className="mb-4 text-xs font-light !leading-snug md:mb-12 md:text-base lg:text-xl lg:!leading-normal xl:text-2xl">
            Loved working with Volkoh. Great communicator and partner, really
            honed in on my demands and requests. Awesome design work, not only
            visually but also in UI/UX. Would definitely recommend working with
            Volkoh, really lifted our project to a higher level. Will
            collaborate again in the future!
          </p>
          <div className="testi-footer flex items-center gap-6">
            <div className="testi-avatar">
              <Image
                src={require("@images/testimonial1.png")}
                width={120}
                height={120}
                alt="Avatar"
                className="w-16 md:w-20 lg:w-28"
              />
            </div>
            <div>
              <p className="text-lg md:text-xl lg:text-2xl ">
                Thierry Hubar
              </p>
              <p className="text-xs font-light md:text-base ">
                Flexi Clean, Netherlands
              </p>
            </div>
          </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
        <div className="testimonial-item px-12">
          <p className="mb-4 text-xs font-light !leading-snug md:mb-12 md:text-base lg:text-xl lg:!leading-normal xl:text-2xl">
            As usual, excellent communication and execution… This is the 6th
            project I did with Volkoh, and definitely, more to come 😊
          </p>
          <div className="testi-footer flex items-center gap-6">
            <div className="testi-avatar">
              <Image
                src={require("@images/testimonial2.png")}
                width={120}
                height={120}
                alt="Avatar"
                className="w-16 md:w-20 lg:w-28"
              />
            </div>
            <div>
              <p className="text-lg md:text-xl lg:text-2xl ">Philipp</p>
              <p className="text-xs font-light md:text-base ">
              Reisigo, Austria
              </p>
            </div>
          </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
        <div className="testimonial-item px-12">
          <p className="mb-4 text-xs font-light !leading-snug md:mb-12 md:text-base lg:text-xl lg:!leading-normal xl:text-2xl">
            Volkoh team are very dedicated to getting the best for your project.
            Great communication and understood what I was looking for in this
            instance. Highly recommended and would do more business in the
            future.
          </p>
          <div className="testi-footer flex items-center gap-6">
            <div className="testi-avatar">
              <Image
                src={require("@images/testimonial3.png")}
                width={120}
                height={120}
                alt="Avatar"
                className="w-16 md:w-20 lg:w-28"
              />
            </div>
            <div>
              <p className="text-lg md:text-xl lg:text-2xl ">
              Alistair Peters
              </p>
              <p className="text-xs font-light md:text-base ">
              PetShack, Australia
              </p>
            </div>
          </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
        <div className="testimonial-item px-12">
          <p className="mb-4 text-xs font-light !leading-snug md:mb-12 md:text-base lg:text-xl lg:!leading-normal xl:text-2xl">
            Very satisfied with the delivered results. Professional
            communication, open for feedback. Would definitely recommend and
            hire him again!
          </p>
          <div className="testi-footer flex items-center gap-6">
            <div className="testi-avatar">
              <Image
                src={require("@images/testimonial4.png")}
                width={120}
                height={120}
                alt="Avatar"
                className="w-16 md:w-20 lg:w-28"
              />
            </div>
            <div>
              <p className="text-lg md:text-xl lg:text-2xl ">
              Floor Hendriks
              </p>
              <p className="text-xs font-light md:text-base ">
              HRM, Netherlands
              </p>
            </div>
          </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
        <div className="testimonial-item px-12">
          <p className="mb-4 text-xs font-light !leading-snug md:mb-12 md:text-base lg:text-xl lg:!leading-normal xl:text-2xl">
            Volkoh continues to deliver over and over again! I’ve been working
            with him for several months now and always come through with great
            looking and consistent designs.
          </p>
          <div className="testi-footer flex items-center gap-6">
            <div className="testi-avatar">
              <Image
                src={require("@images/testimonial5.png")}
                width={120}
                height={120}
                alt="Avatar"
                className="w-16 md:w-20 lg:w-28"
              />
            </div>
            <div>
              <p className="text-lg md:text-xl lg:text-2xl ">
              Jesus Perez
              </p>
              <p className="text-xs font-light md:text-base ">
              Homeloop, USA
              </p>
            </div>
          </div>
        </div>
      </SwiperSlide>
    </Swiper>
  );
}
