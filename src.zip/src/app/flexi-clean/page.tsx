import CaseStudiesHeader from "../components/caseStudies/CaseStudiesHeader";
import Image from "next/image";
import Footer from "../partials/Footer";
import girlWithBucket from "@/assets/images/girl-bucket.png";
import dashboardScreen from "@/assets/images/dashboard-screen.png";
import commas from "@/assets/images/commas.png";
import projectOverview from "@/assets/images/project-overview.png";
import statement1 from "@/assets/images/statements (4).png";
import statement2 from "@/assets/images/statements (3).png";
import statement3 from "@/assets/images/statements (2).png";
import statement4 from "@/assets/images/statements (1).png";
import designProcess from "@/assets/images/design-process-sec.png";
import App1 from "@/assets/images/app (14).png";
import App2 from "@/assets/images/app (13).png";
import App3 from "@/assets/images/app (12).png";
import App4 from "@/assets/images/app (11).png";
import App5 from "@/assets/images/app (10).png";
import App6 from "@/assets/images/app (9).png";
import App7 from "@/assets/images/app (8).png";
import App8 from "@/assets/images/app (7).png";
import App9 from "@/assets/images/app (6).png";
import App10 from "@/assets/images/app (5).png";
import App11 from "@/assets/images/app (4).png";
import App12 from "@/assets/images/app (3).png";
import App13 from "@/assets/images/app (2).png";
import App14 from "@/assets/images/app (1).png";
import web1 from "@/assets/images/web (8).png";
import web2 from "@/assets/images/web (7).png";
import web3 from "@/assets/images/web (6).png";
import web4 from "@/assets/images/web (5).png";
import web5 from "@/assets/images/web (4).png";
import web6 from "@/assets/images/web (3).png";
import web7 from "@/assets/images/web (2).png";
import web8 from "@/assets/images/web (1).png";
import uiApp1 from "@/assets/images/ui-App (8).png";
import uiApp2 from "@/assets/images/ui-App (7).png";
import uiApp3 from "@/assets/images/ui-App (6).png";
import uiApp4 from "@/assets/images/ui-App (5).png";
import uiApp5 from "@/assets/images/ui-App (4).png";
import uiApp6 from "@/assets/images/ui-App (3).png";
import uiApp7 from "@/assets/images/ui-App (2).png";
import uiApp8 from "@/assets/images/ui-App (1).png";
import uiDashboard1 from "@/assets/images/uiDashboard (2).png";
import uiDashboard2 from "@/assets/images/uiDashboard (1).png";
import uiDashboard3 from "@/assets/images/uiDashboard (6).png";
import uiDashboard4 from "@/assets/images/uiDashboard (5).png";
import uiDashboard5 from "@/assets/images/uiDashboard (4).png";
import uiDashboard6 from "@/assets/images/uiDashboard (3).png";
import uiDashboard7 from "@/assets/images/uiDashboard (9).png";
import uiDashboard8 from "@/assets/images/uiDashboard (8).png";
import uiDashboard9 from "@/assets/images/uiDashboard (7).png";
import portfolio1 from "@images/Rectangle 40615portfolio.jpg";
import portfolio2 from "@images/Rectangle 40615portfolio-1.jpg";
import AosComponent from "../components/caseStudies/AosComponent";
import "aos/dist/aos.css";
import cleaningLady from "@images/cleaning-lady.png";
import Link from "next/link";
import {FigmaIcon,UserflowIcon,AIIcon,PSIcon,SlackIcon,MiroIcon,ClickupIcon,ChatGPTIcon} from "@/components/icons/icons"

export default function page() {
  return (
    <>
      <AosComponent />
      <CaseStudiesHeader />
      <section className="flexi-clean-hero lg:pt-20">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="py-10 lg:py-20">
              <Image
                src={girlWithBucket}
                width={415}
                height={258}
                data-aos="zoom-out-right"
                data-aos-delay="1000"
                alt="Flexi clean"
                className="lg:-mb-4 w-full lg:w-auto"
              />
              <h1 className="mb-10 font-semibold text-3xl text-white md:text-7xl">
                Flexi Clean
              </h1>
              <p className="font-light text-base text-white md:text-xl">
                Adaptable, Efficient, and Client-Centric Solutions.
              </p>
            </div>
            <Image
              data-aos="zoom-in-up"
              data-aos-duration="800"
              data-aos-delay="200"
              src={dashboardScreen}
              width={1022}
              height={900}
              alt="Dashboard"
              className="lg:-mb-16 w-full"
            />
          </div>
        </div>
      </section>

      <section className="gap-10 lg:gap-32 grid grid-cols-1 lg:grid-cols-12 py-10 lg:py-40 container">
        <div className="lg:col-span-4" data-aos="fade-up">
          <h4 className="mb-10 font-light text-3xl md:text-4xl">
            Project <span className="font-medium">Duration</span>
          </h4>
          <div className="grid grid-cols-2 mb-4 w-full font-medium text-[#562082] text-2xl md:text-5xl">
            <p>08</p>
            <p>60+</p>
          </div>
          <div className="grid grid-cols-2 mb-4 font-light text-[#878C8E] text-sm md:text-base">
            <p>Weeks</p>
            <p>Screens</p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <h4 className="mb-10 font-light text-3xl md:text-4xl" data-aos="fade-up">
            <span className="font-medium">Tools </span>Used
          </h4>
          <div className="gap-5 grid grid-cols-3 md:grid-cols-4 lg:grid-cols-8">
            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="100">
                <FigmaIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="100" className="text-[#878C8E]">Figma</p>
            </div>

            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="200">
                <UserflowIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="200" className="text-[#878C8E]">Userflow</p>
            </div>

            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="300">
                <AIIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="300" className="text-[#878C8E]">AI</p>
            </div>

            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="400">
                <PSIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="400" className="text-[#878C8E]">PS</p>
            </div>

            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="500">
                <SlackIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="500" className="text-[#878C8E]">Slack</p>
            </div>

            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="600">
                <MiroIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="600" className="text-[#878C8E]">Miro</p>
            </div>

            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="700">
                <ClickupIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="700" className="text-[#878C8E]">ClickUp</p>
            </div>

            <div>
              <div className="mb-3" data-aos="flip-right" data-aos-delay="800">
                <ChatGPTIcon/>
              </div>
              <p data-aos="fade-up" data-aos-delay="800" className="text-[#878C8E]">ChatGPT</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2">
          <div>
            <h2 className="mb-10 font-light text-2xl md:text-7xl" data-aos="fade-up">
              Project <br className="lg:block hidden" />
              <span className="font-medium">Overview</span>
            </h2>
            <Image
              className="mt-20"
              width={812}
              height={1132}
              src={projectOverview}
              alt="Project Overview" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="200"
            />
          </div>
          <div>
            <div data-aos="fade-up" data-aos-duration="500">
              <div className="flex items-center gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="10"
                  height="16"
                  fill="none"
                  viewBox="0 0 10 16"
                >
                  <path
                    fill="#17191B"
                    d="M9.174 8.743L1.67 15.498c-.644.58-1.669.122-1.669-.743V1.245C0 .38 1.025-.077 1.669.502l7.505 6.755a1 1 0 010 1.486z"
                  ></path>
                </svg>
                <h3 className="font-medium text-lg md:text-2xl">
                  Market Analysis
                </h3>
              </div>
              <div className="flex lg:flex-row flex-col justify-between items-center gap-10">
                <Image
                  src={commas}
                  alt="puntuation"
                  width={136}
                  height={83}
                  className="mt-10 lg:mt-0 md:mr-auto lg:mr-0"
                />
                <p className="my-5 font-light text-[#878C8E] text-base md:text-lg">
                  The cleaning industry in the Netherlands has traditionally
                  operated under rigid contracts and lacked modern technological
                  integration.
                </p>
              </div>
              <p className="my-5 font-light text-[#878C8E] text-base md:text-lg">
                However, the onset of the COVID-19 pandemic has highlighted the
                need for more flexible and adaptive cleaning solutions. There is
                a growing demand for cleaning services that can swiftly adjust
                to changing occupancy levels and evolving client requirements.
                Flexi Clean recognizes this market shift and aims to capitalize
                on it by introducing a tech-enhanced cleaning service platform.
              </p>
            </div>

            <div data-aos="fade-up" data-aos-duration="500">
              <div className="flex items-center gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="10"
                  height="16"
                  fill="none"
                  viewBox="0 0 10 16"
                >
                  <path
                    fill="#17191B"
                    d="M9.174 8.743L1.67 15.498c-.644.58-1.669.122-1.669-.743V1.245C0 .38 1.025-.077 1.669.502l7.505 6.755a1 1 0 010 1.486z"
                  ></path>
                </svg>
                <h3 className="font-medium text-lg md:text-2xl">
                  Technological Innovation
                </h3>
              </div>
              <p className="my-5 font-light text-[#878C8E] text-base md:text-lg">
                However, the onset of the COVID-19 pandemic has highlighted the
                need for more flexible and adaptive cleaning solutions. There is
                a growing demand for cleaning services that can swiftly adjust
                to changing occupancy levels and evolving client requirements.
                Flexi Clean recognizes this market shift and aims to capitalize
                on it by introducing a tech-enhanced cleaning service platform.
              </p>
            </div>

            <div data-aos="fade-up" data-aos-duration="500">
              <div className="flex items-center gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="10"
                  height="16"
                  fill="none"
                  viewBox="0 0 10 16"
                >
                  <path
                    fill="#17191B"
                    d="M9.174 8.743L1.67 15.498c-.644.58-1.669.122-1.669-.743V1.245C0 .38 1.025-.077 1.669.502l7.505 6.755a1 1 0 010 1.486z"
                  ></path>
                </svg>
                <h3 className="font-medium text-lg md:text-2xl">
                  Client-Centric Approach
                </h3>
              </div>
              <p className="my-5 font-light text-[#878C8E] text-base md:text-lg">
                At the core of Flexi Clean&apos;s project is a client-centric
                approach aimed at enhancing user experience and satisfaction.
                The platform&apos;s intuitive user interfaces enable clients to
                easily communicate their changing needs and view service
                schedules. Moreover, interactive tools for customization empower
                businesses to tailor cleaning plans precisely to their
                requirements. By prioritizing clarity of information and ease of
                use, Flexi Clean ensures that clients can make informed
                decisions and swiftly book cleaning services as needed.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-10 lg:py-40 project-statement-bg">
        <div className="container">
          <h2 className="mb-5 font-medium text-2xl md:text-5xl">
            Project Statement
          </h2>
          <p className="mb-5 font-light text-[#878C8E] text-sm md:text-base">
            The project entails the design and development of a cutting-edge
            cleaning service platform that utilizes real-time occupancy data and
            smart scheduling algorithms to optimize resource allocation and
            provide adaptive cleaning schedules. Through intuitive user
            interfaces and scalable features, the platform aims to revolutionize
            the way cleaning services are delivered, enhancing efficiency,
            adaptability, and client satisfaction.
          </p>
          <div className="gap-10 md:gap-5 grid grid-cols-1 md:grid-cols-2 my-20">
            <div>
              <Image
                src={statement1}
                width={992.17}
                height={491.27}
                alt="Project Statement"
                className="mb-10"
                data-aos="fade-right"
              />
              <Image
                src={statement2}
                width={675.8}
                height={387.46}
                alt="Project Statement"
                data-aos="fade-right"
              />
            </div>
            <div>
              <Image
                src={statement3}
                width={632}
                height={245}
                alt="Project Statement"
                className="mb-10"
                data-aos="fade-left"
              />
              <Image
                src={statement4}
                width={702}
                height={778}
                alt="Project Statement"
                data-aos="fade-left"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="my-5 lg:my-10 goals-bg">
        <div className="items-center gap-10 xl:gap-20 grid grid-cols-1 xl:grid-cols-2 container">
          <div data-aos="fade-right">
            <h2 className="font-medium text-2xl md:text-6xl">Goals</h2>
            <ol className="p-5 leading-normal md:leading-relaxed list-decimal">
              <li className="mb-5">
                Design a visually coherent and user-friendly platform
                encompassing a desktop landing page, client app/web app, and an
                employee app.
              </li>
              <li className="mb-5">
                Implement intuitive user interfaces that enable clients to
                easily communicate changing needs and view service schedules.
              </li>
              <li className="mb-5">
                Develop scalable features capable of accommodating various
                client sizes and demands.
              </li>
              <li className="mb-5">
                Incorporate a client-centric approach focusing on user
                experience, ease of use, and clarity of information.
              </li>
              <li className="mb-5">
                Create interactive tools for customization, allowing businesses
                to tailor cleaning plans precisely to their requirements.
              </li>
              <li className="mb-5">
                Provide realistic visualizations of the proposed tech-enhanced
                cleaning service platform for investor presentations.
              </li>
              <li className="mb-5">
                Align the platform with market demands, enhancing service
                levels, and client satisfaction.
              </li>
              <li className="mb-5">
                Deliver a comprehensive visual concept for the platform in Dutch
                language to attract further investment and demonstrate its
                potential impact on the cleaning industry.
              </li>
            </ol>
          </div>
          <div data-aos="fade-left">
            <Image src={cleaningLady} width={615} height={696} alt="Goals" />
          </div>
        </div>
      </section>

      <section className="py-20 design-process">
        <div className="container">
          <h2 className="mb-5 font-medium text-6xl text-center text-white">
            Design Process
          </h2>
          <Image
            width={1770}
            height={1111}
            src={designProcess}
            alt="Design process"
            data-aos="zoom-in"
          />
        </div>
      </section>

      <section className="md:my-20 py-10 container">
        <h2 className="font-medium text-3xl md:text-6xl">Hi-Fi Wireframe</h2>
        <div className="bg-[#F3F7FF] my-10 p-10 rounded-md">
          <h3 className="font-medium text-2xl">App</h3>
          <div className="gap-2 grid grid-cols-2 md:grid-cols-7 my-10">
            <Image
              src={App1}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App2}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App3}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App4}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App5}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App6}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App7}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App8}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App9}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App10}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App11}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App12}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App13}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
            <Image
              src={App14}
              width={228}
              height={469.68}
              alt="App"
              className="mb-5"
            />
          </div>
        </div>

        <div className="bg-[#F3F7FF] p-10 rounded-md">
          <h3 className="mb-10 font-medium text-2xl">Web</h3>
          <div className="gap-2 grid grid-cols-1 md:grid-cols-4">
            <Image
              src={web1}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
            <Image
              src={web2}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
            <Image
              src={web3}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
            <Image
              src={web4}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
            <Image
              src={web5}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
            <Image
              src={web6}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
            <Image
              src={web7}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
            <Image
              src={web8}
              width={407.29}
              height={276}
              alt="App"
              className="mb-5"
            />
          </div>
        </div>
      </section>

      <section className="py-10 md:py-32 ui-app-bg">
        <div className="container">
          <h2 className="font-medium text-3xl text-white md:text-6xl">
            UI App
          </h2>
          <div className="gap-5 grid grid-cols-1 md:grid-cols-4 mt-32">
            <Image
              data-aos="fade-down"
              src={uiApp1}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
            <Image
              data-aos="fade-up"
              src={uiApp2}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
            <Image
              data-aos="fade-down"
              src={uiApp3}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
            <Image
              data-aos="fade-down"
              src={uiApp4}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
            <Image
              data-aos="fade-up"
              src={uiApp5}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
            <Image
              data-aos="fade-down"
              src={uiApp6}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
            <Image
              data-aos="fade-up"
              src={uiApp7}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
            <Image
              data-aos="fade-down"
              src={uiApp8}
              width={420}
              height={846}
              alt="App"
              className="md:odd:mt-32 mb-5"
            />
          </div>
        </div>
      </section>

      <section className="pt-10 md:pt-40 ui-dashboard">
        <div className="container">
          <h1 className="font-medium text-3xl md:text-6xl">Ui Dashboard</h1>
          <div data-aos="fade-down-right">
            <div className="gap-10 grid grid-cols-3 mt-10 -rotate-[15deg]">
              <div className="md:mt-32">
                <Image
                  src={uiDashboard1}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                  className="mb-10"
                />
                <Image
                  src={uiDashboard2}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                />
              </div>
              <div>
                <Image
                  src={uiDashboard3}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                  className="mb-10"
                />
                <Image
                  src={uiDashboard4}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                  className="mb-10"
                />
                <Image
                  src={uiDashboard5}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                  className="mb-10"
                />
                <Image
                  src={uiDashboard6}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                />
              </div>
              <div className="md:mt-32">
                <Image
                  src={uiDashboard7}
                  width={1112}
                  height={1202}
                  alt="Ui Dashboard"
                  className="mb-10"
                />
                <Image
                  src={uiDashboard8}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                  className="mb-10"
                />
                <Image
                  src={uiDashboard9}
                  width={1112}
                  height={718.17}
                  alt="Ui Dashboard"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="relative z-10 bg-[#F3F7FF] py-32">
        <div className="container">
          <h2 className="mb-10 font-medium text-3xl md:text-7xl">
            Recent Work
          </h2>
          <div className="gap-12 lg:gap-32 grid grid-cols-1 lg:grid-cols-2">
            <Link
              href="homeloop"
              data-aos="fade-right"
              className="lg:odd:mt-24 duration-300 ease-in-out portfolio-item"
            >
              <div className="relative mb-4 img-wrap">
                <Image
                  src={portfolio1}
                  width={812}
                  height={880}
                  alt="Portfolio Image"
                  className="rounded-lg"
                />
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 120 120"
                  className="right-5 xl:right-10 bottom-5 xl:bottom-10 absolute opacity-0 w-[80px] xl:w-[120px] h-[80px] xl:h-[120px] portfolio-inner"
                >
                  <circle cx="60" cy="60" r="60" fill="#3239FF"></circle>
                  <path
                    stroke="#fff"
                    strokeWidth="4"
                    d="M60 40.8v38.4M79.2 60H40.8"
                  ></path>
                </svg>
              </div>
              <div className="md:p-6 portfolio-content">
                <h4 className="mb-3 md:mb-6 text-lg md:text-xl lg:text-2xl xl:text-3xl">
                  Homeloop
                </h4>
                <p className="mb-4 font-light text-xs md:text-base lg:text-lg">
                  A dynamic platform for property managers to streamline their
                  ope...
                </p>
                <div className="md:flex items-center gap-2 md:gap-4 lg:gap-6 hidden font-light portfolio-tags">
                  <span>
                    <span className="text-xs md:text-sm">Real Estate</span>
                    <span className="last:hidden bg-[#323639] rounded-full w-[5px] h-[5px]"></span>
                  </span>
                  <span>
                    <span className="text-xs md:text-sm">
                      Property Management
                    </span>
                    <span className="last:hidden bg-[#323639] rounded-full w-[5px] h-[5px]"></span>
                  </span>
                  <span>
                    <span className="text-xs md:text-sm">User Experience</span>
                    <span className="last:hidden bg-[#323639] rounded-full w-[5px] h-[5px]"></span>
                  </span>
                </div>
              </div>
            </Link>

            <Link
              href="/petshack-case-study"
              data-aos="fade-left"
              className="lg:odd:mt-24 duration-300 ease-in-out portfolio-item"
            >
              <div className="relative mb-4 img-wrap">
                <Image
                  src={portfolio2}
                  width={812}
                  height={880}
                  alt="Portfolio Image"
                  className="rounded-lg"
                />
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 120 120"
                  className="right-5 xl:right-10 bottom-5 xl:bottom-10 absolute opacity-0 w-[80px] xl:w-[120px] h-[80px] xl:h-[120px] portfolio-inner"
                >
                  <circle cx="60" cy="60" r="60" fill="#3239FF"></circle>
                  <path
                    stroke="#fff"
                    strokeWidth="4"
                    d="M60 40.8v38.4M79.2 60H40.8"
                  ></path>
                </svg>
              </div>
              <div className="md:p-6 portfolio-content">
                <h4 className="mb-3 md:mb-6 text-lg md:text-xl lg:text-2xl xl:text-3xl">
                  Petshack
                </h4>
                <p className="mb-4 font-light text-xs md:text-base lg:text-lg">
                  An engaging app that connects pet owners with local pet
                  services...
                </p>
                <div className="md:flex items-center gap-2 md:gap-4 lg:gap-6 hidden font-light portfolio-tags">
                  <span>
                    <span className="text-xs md:text-sm">Pet Care</span>
                    <span className="last:hidden bg-[#323639] rounded-full w-[5px] h-[5px]"></span>
                  </span>
                  <span>
                    <span className="text-xs md:text-sm">Mobile App</span>
                    <span className="last:hidden bg-[#323639] rounded-full w-[5px] h-[5px]"></span>
                  </span>
                  <span>
                    <span className="text-xs md:text-sm">User Engagement</span>
                    <span className="last:hidden bg-[#323639] rounded-full w-[5px] h-[5px]"></span>
                  </span>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
